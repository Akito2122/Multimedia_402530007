import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class calcu_b extends JApplet {
   public void init() {
	  CalcuPanel calc=new CalcuPanel();
      getContentPane().add(calc);
      calc.setLayout(null);
      setSize(395, 600);
      }
   }

   class CalcuPanel extends JPanel implements ActionListener 
   {
	  private static final Font font = new Font("monspaced", Font.PLAIN, 30);
      JButton num1,num2,num3,num4,num5,num6,num7,num8,num9,num0,pl,mi,mu,di,dot,ce,equal;
      static JTextField answer,record;
      static String LCD = null;
      JOptionPane p = new JOptionPane();
      double PR = 0,SV = 0,RE;

      private static void as(String nu)
        {
         if((answer.getText()).equals("0"))
         {
        	 answer.setText(nu);
        	 record.setText("Last input : " + nu);
         }
          else if(LCD == "=")
           {
        	  answer.setText(nu);
        	  record.setText("Last input : " + nu);
        	  LCD = null;
           }
          else
        	  answer.setText(answer.getText() + nu);
              record.setText("Last input : " + answer.getText());
         }
   
   public CalcuPanel() {
	   
	   //Button start
	   
       answer = new JTextField("0", 12);
       answer.setFont(font);
       answer.setHorizontalAlignment(JTextField.RIGHT);
       answer.setBounds(10, 10, 374, 59);
       add(answer);
       
       record = new JTextField("Last input : ", 12);
       record.setFont(font);
       record.setBounds(10, 530, 375, 60);
       record.setHorizontalAlignment(JTextField.RIGHT);
       record.setBounds(10, 530, 375, 60);
       add(record);
       
       num7= new JButton("7");
       num7.setFont(font);
       num7.setBounds(10, 79, 87, 80);
       add(num7);
       num7.addActionListener(this);
       
       num8 = new JButton("8");
       num8.setFont(font);
       num8.setBounds(107, 79, 87, 80);
       add(num8);
       num8.addActionListener(this);
       
       num9 = new JButton("9");
       num9.setFont(font);
       num9.setBounds(204, 79, 87, 80);
       add(num9);
       num9.addActionListener(this);
       
       num4 = new JButton("4");
       num4.setFont(font);
       num4.setBounds(10, 169, 87, 80);
       add(num4);
       num4.addActionListener(this);
       
       num5 = new JButton("5");
       num5.setFont(font);
       num5.setBounds(107, 169, 87, 80);
       add(num5);
       num5.addActionListener(this);
       
       num6 = new JButton("6");
       num6.setFont(font);
       num6.setBounds(204, 169, 87, 80);
       add(num6);
       num6.addActionListener(this);
       
       num1 = new JButton("1");
       num1.setFont(font);
       num1.setBounds(10, 259, 87, 80);
       add(num1);
       num1.addActionListener(this);
       
       num2 = new JButton("2");
       num2.setFont(font);
       num2.setBounds(107, 259, 87, 80);
       add(num2);
       num2.addActionListener(this);
       
       num3 = new JButton("3");
       num3.setFont(font);
       num3.setBounds(204, 259, 87, 80);
       add(num3);
       num3.addActionListener(this);
       
       num0 = new JButton("0");
       num0.setFont(font);
       num0.setBounds(10, 349, 184, 80);
       add(num0);
       num0.addActionListener(this);
       
       dot = new JButton(".");
       dot.setFont(font);
       dot.setBounds(204, 349, 87, 80);
       add(dot);
       dot.addActionListener(this);
       
       pl = new JButton("+");
       pl.setFont(font);
       pl.setBounds(297, 79, 87, 80);
       add(pl);
       pl.addActionListener(this);
       
       mi = new JButton("-");
       mi.setFont(font);
       mi.setBounds(297, 169, 87, 80);
       add(mi);
       mi.addActionListener(this);
       
       mu = new JButton("*");
       mu.setFont(font);
       mu.setBounds(297, 259, 87, 80);
       add(mu);
       mu.addActionListener(this);
       
       di = new JButton("/");
       di.setFont(font);
       di.setBounds(297, 349, 87, 80);
       add(di);
       di.addActionListener(this);
       
       ce = new JButton("CE");
       ce.setFont(font);
       ce.setBounds(10, 439, 182, 80);
       add(ce);
       ce.addActionListener(this);
       
       equal = new JButton("=");
       equal.setFont(font);
       equal.setBounds(202, 439, 182, 80);
       add(equal);
       equal.addActionListener(this);
       
       //Button finish
       
    }
    public void actionPerformed(ActionEvent ae)
       {
    if(ae.getSource()==num1) as("1");
    else if(ae.getSource()==num2) as("2");
    else if(ae.getSource()==num3) as("3");
    else if(ae.getSource()==num4) as("4");
    else if(ae.getSource()==num5) as("5");
    else if(ae.getSource()==num6) as("6");
    else if(ae.getSource()==num7) as("7");
    else if(ae.getSource()==num8) as("8");
    else if(ae.getSource()==num9) as("9");
    else if(ae.getSource()==num0) as("0");
    else if(ae.getSource()==dot)
          {
           if(((answer.getText()).indexOf("."))==-1)
        	   answer.setText(answer.getText()+".");
         }
    else if(ae.getSource()==mi)
           {
    	   PR=Double.parseDouble(answer.getText());
           LCD="-";
           answer.setText("0");
           record.setText("Last input : " + LCD);
           }
    else if(ae.getSource()==di)
           {
           PR=Double.parseDouble(answer.getText());
           LCD="/";
           answer.setText("0");
           record.setText("Last input : " + LCD);
           }
    else if(ae.getSource()==equal)
           {
           SV=Double.parseDouble(answer.getText());
           if(LCD.equals("/"))
                RE=PR/SV;
           else if(LCD.equals("*"))
                RE=PR*SV;
           else if(LCD.equals("-"))
                RE=PR-SV;
           else if(LCD.equals("+"))
                RE=PR+SV;
           answer.setText(" "+RE);
           LCD="=";
           }
    else if(ae.getSource()==mu)
           {
    	   PR=Double.parseDouble(answer.getText());
            LCD="*";
            answer.setText("0");
            record.setText("Last input : " + LCD);
            }
    else if(ae.getSource()==pl)
            {
    	    PR=Double.parseDouble(answer.getText());
            LCD="+";
            answer.setText("0");
            record.setText("Last input : " + LCD);
            }
    else if(ae.getSource()==ce)
            {
            PR=Double.parseDouble(answer.getText());
            LCD = "";
            answer.setText("0");
            record.setText("Last input : " + LCD);
            }
     }
   }