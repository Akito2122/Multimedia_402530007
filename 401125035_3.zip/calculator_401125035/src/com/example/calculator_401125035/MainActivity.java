package com.example.calculator_401125035;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

	Button num1,num2,num3,num4,num5,num6,num7,num8,num9,num0,pl,mi,mu,di,dot,ce,equal;
	static EditText answer;
	String PR = "0",SV = "0",RE;
	int indexValue = 0;
	int indexOperation;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		SetObjFunction();
		SetMyOnClick();
	}
	private void SetMyOnClick() {
		num1.setOnClickListener(MyOnClick);
		num2.setOnClickListener(MyOnClick);
		num3.setOnClickListener(MyOnClick);
		num4.setOnClickListener(MyOnClick);
		num5.setOnClickListener(MyOnClick);
		num6.setOnClickListener(MyOnClick);
		num7.setOnClickListener(MyOnClick);
		num8.setOnClickListener(MyOnClick);
		num9.setOnClickListener(MyOnClick);
		num0.setOnClickListener(MyOnClick);
		pl.setOnClickListener(MyOnClick);
		mi.setOnClickListener(MyOnClick);
		mu.setOnClickListener(MyOnClick);
		di.setOnClickListener(MyOnClick);
		dot.setOnClickListener(MyOnClick);
		ce.setOnClickListener(MyOnClick);
		equal.setOnClickListener(MyOnClick);
	}
	private void SetObjFunction() {
		answer = (EditText) findViewById(R.id.answer);
		record = (EditText) findViewById(R.id.record);
		num1 = (Button) findViewById(R.id.num1);
		num2 = (Button) findViewById(R.id.num2);
		num3 = (Button) findViewById(R.id.num3);
		num4 = (Button) findViewById(R.id.num4);
		num5 = (Button) findViewById(R.id.num5);
		num6 = (Button) findViewById(R.id.num6);
		num7 = (Button) findViewById(R.id.num7);
		num8 = (Button) findViewById(R.id.num8);
		num9 = (Button) findViewById(R.id.num9);
		num0 = (Button) findViewById(R.id.num0);
		pl = (Button) findViewById(R.id.pl);
		mi = (Button) findViewById(R.id.mi);
		mu = (Button) findViewById(R.id.mu);
		di = (Button) findViewById(R.id.di);
		dot = (Button) findViewById(R.id.dot);
		ce = (Button) findViewById(R.id.ce);
		equal = (Button) findViewById(R.id.equal);
		answer.setText("0");
	}
	private Button.OnClickListener MyOnClick= new Button.OnClickListener () 
	{
		
		public void onClick(View v)
		{
			String buttomValue;
			buttomValue = answer.getText().toString();
			switch (v.getId()){
				case R.id.num0:
					DisPlayNU("0");
					break;
				case R.id.num1:
					DisPlayNU("1");
					break;
				case R.id.num2:
					DisPlayNU("2");
					break;
				case R.id.num3:
					DisPlayNU("3");
					break;
				case R.id.num4:
					DisPlayNU("4");
					break;
				case R.id.num5:
					DisPlayNU("5");
					break;
				case R.id.num6:
					DisPlayNU("6");
					break;
				case R.id.num7:
					DisPlayNU("7");
					break;
				case R.id.num8:
					DisPlayNU("8");
					break;
				case R.id.num9:
					DisPlayNU("9");
					break;
				case R.id.dot:
					DisPlayNU(".");
					break;
				case R.id.pl:
					Calculate(0 , buttomValue);
					break;
				case R.id.mi:
					Calculate(1 , buttomValue);
					break;
				case R.id.mu:
					Calculate(2 , buttomValue);
					break;
				case R.id.di:
					Calculate(3 , buttomValue);
					break;
				case R.id.equal:
					Calculate(99 , "0");
					break;
				case R.id.ce:
					answer.setText("0");
					break;
			}
		}
	};
	private void DisPlayNU(String putin)
	{
		String temp;
		temp=answer.getText().toString();	
		if (temp.equals("0")|| indexValue == 1)
		{
			answer.setText(putin);
			indexValue = 0;
		}
		else
		{answer.setText(temp + putin);}
	}
	private void Calculate(int operation , String tempAnswer)
	{
		double x;
		String finalAnswer;
		switch (operation)
		{
		case 0:  
			PR = tempAnswer;
			indexOperation = 0;
			answer.setText(""); 
			break;
		case 1:  
			PR = tempAnswer;
			indexOperation = 1;
			answer.setText(""); 
			break;
		case 2:  
			PR = tempAnswer;
			indexOperation = 2;
			answer.setText(""); 
			break;
		case 3:  
			PR = tempAnswer;
			indexOperation = 3;
			answer.setText(""); 
			break;	
		case 99:
			SV = answer.getText().toString();
			double  i=Double.valueOf(PR);
			double  j=Double.valueOf(SV);
			switch(indexOperation)
			{
			case 0:
				x = i + j;
				finalAnswer = Double.toString(x);
				answer.setText(finalAnswer);
				break;
			case 1:
				x = i - j;
				finalAnswer = Double.toString(x);
				answer.setText(finalAnswer);	
				break;
			case 2:
				x = i * j;
				finalAnswer = Double.toString(x);
				answer.setText(finalAnswer);
				break;
			case 3:
				if (j == 0)
					answer.setText("ERROR:�������i��0");
				x = i / j;
				finalAnswer = Double.toString(x);
				answer.setText(finalAnswer);
				break;
			}
		break;
		}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
	// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
}
