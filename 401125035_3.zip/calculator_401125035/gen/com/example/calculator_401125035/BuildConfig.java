/** Automatically generated file. DO NOT MODIFY */
package com.example.calculator_401125035;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}